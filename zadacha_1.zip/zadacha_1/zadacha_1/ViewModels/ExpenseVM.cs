﻿using System.Collections.Generic;
using BorrowLend.Models;

namespace BorrowLend.ViewModels
{
    public class ExpenseVM
    {
        public Expense Expense { get; set; }
        public IEnumerable<ExpenseType> ExpenseTypes { get; set; }
    }
}