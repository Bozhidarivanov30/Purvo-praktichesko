﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace BorrowLend.Models
{
    public class Expense
    {
        [Key]
        public int ID { get; set; }

        [Required]
        public string ExpenseName { get; set; }

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Amount must be a positive number")]
        public decimal Amount { get; set; }

        // Foreign Key for ExpenseType
        public int ExpenseTypeId { get; set; }

        // Navigation property for ExpenseType
        [ForeignKey("ExpenseTypeId")]
        public virtual ExpenseType ExpenseType { get; set; }
    }
}
