﻿using System.ComponentModel.DataAnnotations;

namespace BorrowLend.Models
{
    public class Item
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "Item name")]
        [Required(ErrorMessage = "Item name is required.")]
        public string ItemName { get; set; }

        [Required(ErrorMessage = "Borrower is required.")]
        public string Borrower { get; set; }

        [Required(ErrorMessage = "Lender is required.")]
        public string Lender { get; set; }
        [Required]
        [RegularExpression(@"^[a-zA-Z0-9._]+@[a-zA-Z]+\.[a-zA-Z]+$", ErrorMessage = "Невалиден Email формат.")]
        public string Email { get; set; }

        // Поле PhoneNumber с валидация само за 8 цифри
        [Required]
        [RegularExpression(@"^\d{8}$", ErrorMessage = "Телефонният номер трябва да съдържа точно 8 цифри.")]
        public string PhoneNumber { get; set; }
    }
}
