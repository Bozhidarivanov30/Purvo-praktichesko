﻿using Microsoft.AspNetCore.Mvc;
using BorrowLend.Data;
using BorrowLend.Models;
using System.Linq;
using BorrowLend.ViewModels;

namespace BorrowLend.Controllers
{
    public class ExpenseController : Controller
    {
        private readonly ApplicationDbContext _db;

        public ExpenseController(ApplicationDbContext db)
        {
            _db = db;
        }

        
        public IActionResult Index()
        {
            var expenses = _db.Expenses.ToList();
            return View(expenses);
        }


        public IActionResult Create()
        {
            var expenseVM = new ExpenseVM
            {
                Expense = new Expense(),
                ExpenseTypes = _db.ExpenseTypes.ToList()
            };
            return View(expenseVM);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ExpenseVM expenseVM)
        {
            if (ModelState.IsValid)
            {
                _db.Expenses.Add(expenseVM.Expense);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            expenseVM.ExpenseTypes = _db.ExpenseTypes.ToList();
            return View(expenseVM);
        }

        public IActionResult Update(int id)
        {
            var expense = _db.Expenses.Find(id);
            if (expense == null)
            {
                return NotFound();
            }
            return View(expense);
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Update(Expense expense)
        {
            if (ModelState.IsValid)
            {
                _db.Expenses.Update(expense);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(expense);
        }

        
        public IActionResult Delete(int id)
        {
            var expense = _db.Expenses.Find(id);
            if (expense == null)
            {
                return NotFound();
            }
            return View(expense);
        }

        
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var expense = _db.Expenses.Find(id);
            _db.Expenses.Remove(expense);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
        
    }
}

